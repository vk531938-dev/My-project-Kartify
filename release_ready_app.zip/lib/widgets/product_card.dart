import 'package:flutter/material.dart';
import '../models/product.dart';

class ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback? onTap;
  const ProductCard({required this.product, this.onTap, super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: product.image != null
                  ? Image.network(product.image!, fit: BoxFit.cover, width: double.infinity)
                  : Container(color: Colors.grey[300], child: Center(child: Icon(Icons.image, size: 48))),
            ),
            Padding(
              padding: EdgeInsets.all(8),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(product.name, style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: 4),
                Text('₹${product.price.toStringAsFixed(2)}'),
              ]),
            )
          ],
        ),
      ),
    );
  }
}
