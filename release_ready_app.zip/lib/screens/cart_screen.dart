import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';
import '../services/firebase_service.dart';

class CartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cart = Provider.of<CartProvider>(context);
    final firebase = FirebaseService();

    return Scaffold(
      appBar: AppBar(title: Text('Your Cart')),
      body: Column(
        children: [
          Expanded(
            child: cart.items.isEmpty
                ? Center(child: Text('Cart is empty'))
                : ListView.builder(
                    itemCount: cart.items.length,
                    itemBuilder: (context, index) {
                      String key = cart.items.keys.toList()[index];
                      final item = cart.items[key]!;
                      return ListTile(
                        leading: item.image != null ? Image.network(item.image!, width: 50) : null,
                        title: Text(item.title),
                        subtitle: Text('Qty: ${item.quantity}'),
                        trailing: Text('₹${(item.price * item.quantity).toStringAsFixed(2)}'),
                      );
                    },
                  ),
          ),
          Container(
            padding: EdgeInsets.all(16),
            child: Column(
              children: [
                Text('Total: ₹${cart.totalAmount.toStringAsFixed(2)}', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: cart.items.isEmpty
                      ? null
                      : () {
                          // For demo: open Razorpay with total
                          firebase.openCheckout(cart.totalAmount, 'Order Payment');
                        },
                  child: Text('Checkout'),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
