import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';
import '../services/firebase_service.dart';

class ProductDetailScreen extends StatelessWidget {
  final Product product;
  const ProductDetailScreen({required this.product, super.key});

  @override
  Widget build(BuildContext context) {
    final firebase = FirebaseService();
    return Scaffold(
      appBar: AppBar(title: Text(product.name)),
      body: Column(
        children: [
          Expanded(child: product.image != null ? Image.network(product.image!, fit: BoxFit.cover) : SizedBox()),
          Padding(
            padding: EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(product.name, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('₹${product.price.toStringAsFixed(2)}', style: TextStyle(fontSize: 18)),
              SizedBox(height: 12),
              Text(product.description),
              SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Provider.of<CartProvider>(context, listen: false).addToCart(product);
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Added to cart')));
                      },
                      child: Text('Add to Cart'),
                    ),
                  ),
                  SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: () {
                      firebase.openCheckout(product.price, product.name);
                    },
                    child: Text('Buy Now'),
                  ),
                ],
              )
            ]),
          )
        ],
      ),
    );
  }
}
