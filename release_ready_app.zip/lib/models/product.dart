class Product {
  final String id;
  final String name;
  final String description;
  final double price;
  final String? image;

  Product({required this.id, required this.name, required this.description, required this.price, this.image});

  factory Product.fromMap(String id, Map<String, dynamic> data) => Product(
        id: id,
        name: data['name'] ?? '',
        description: data['description'] ?? '',
        price: (data['price'] ?? 0).toDouble(),
        image: data['image'],
      );
}
