# User Ecommerce App (Ready-made)

This is a ready-made Flutter user/customer ecommerce app template.
Features:
- Home screen with product grid (fetch from Firestore)
- Product detail page
- Cart (Provider) with add/remove and total
- Orders placeholder
- Razorpay integration hook (replace key)

Setup:
1. Place your `google-services.json` into `android/app/`.
2. Run `flutter pub get`.
3. Replace RAZORPAY_KEY in services/firebase_service.dart with your key.
4. Run `flutter run`.

Firestore:
- Create `products` collection with documents having fields:
  name (string), description (string), price (number), image (string)

